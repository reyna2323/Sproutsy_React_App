// src/utils/plantService.js
import { db, auth } from '../firebase';
import { collection, addDoc, getDocs, query, where } from "firebase/firestore";

export async function savePlantForUser(plant) {
  const user = auth.currentUser;
  if (!user) throw new Error("User not logged in");

  const plantWithMeta = {
    ...plant,
    userId: user.uid,
    createdAt: new Date(),
  };

  await addDoc(collection(db, "plants"), plantWithMeta);
}

export async function getPlantsForUser() {
  const user = auth.currentUser;
  if (!user) throw new Error("User not logged in");

  const q = query(collection(db, "plants"), where("userId", "==", user.uid));
  const querySnapshot = await getDocs(q);
  return querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
}